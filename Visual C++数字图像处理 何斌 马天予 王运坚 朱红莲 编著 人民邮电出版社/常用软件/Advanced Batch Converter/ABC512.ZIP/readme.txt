Advanced Batch Converter for Win9x/NT/2000
version: 2.3 Release

************************************************
Original size: 967055 bytes
 Install size: 970654 bytes
************************************************

Advanced Batch Converter is a nice utility you 
can use to easily convert graphic files in normal
(file by file) and batch (many files at a time) 
mode. 

Input formats:         
BMP, JPG, GIF, PNG, TIF, JPEG, RLE,
DIB, PCD, ICB, ICO, WMF, TIFF, TGA,
PCX, SCR, EMF, JIF, VDA, JFIF, RGB,
AFI, VST, WIN, CEL, JPE, RGBA, PIC,
PCC, CUT, PPM, PGM, PBM, SGI,  RLA,
RPF, PSD, PDD, BW.

Output formats:        
BMP, JPG, JPEG, GIF, PNG, PCX, TGA, 
EPS, TIF, TIFF, ICO.

Also includes an image viewer to easily display 
all supported formats. 
*************************************************

license: Evaluation Trial ($25 USD)
website: http://www.gold-software.com
e-mail:  info@gold-software.com
ICQ UIN: 31167035